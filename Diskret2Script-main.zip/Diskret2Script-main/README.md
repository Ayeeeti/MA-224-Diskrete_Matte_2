# Diskret Matematik Python Project

This repository contains various Python scripts and programs related to discrete mathematics. Each script explores a specific concept or solves a problem within the field.

---

## Project Structure

### Files and Their Purpose

| File Name                        | Description                                                                 |
|----------------------------------|-----------------------------------------------------------------------------|
| `abcFormula`                     | Implements the ABC formulas.                                               |
| `ambigous`                       | Handles ambiguous cases in discrete math tasks.                            |
| `base_converter`                 | Converts numbers between different bases.                                  |
| `derivation`                     | Script for deriving mathematical expressions.                              |
| `find_quotient_and_remainder`    | Computes the quotient and remainder of numbers.                            |
| `gcd`                            | Calculates the greatest common divisor (GCD).                             |
| `grammarStrings.py`              | Operates on grammar strings for parsing and analysis.                      |
| `hammingdistance.py`             | Calculates the Hamming distance between two binary strings.                |
| `lcd`                            | Finds the least common divisor (LCD).                                      |
| `mod`                            | Performs modular arithmetic operations.                                    |
| `noisyBinarySymmetricChannel`    | Simulates a noisy binary symmetric channel.                                |
| `oppgave1bob`                    | Solution or example related to a specific discrete mathematics problem.    |
| `oppgave3Gmatrise`               | Solves problems involving matrices (specific to Task 3).                   |
| `primeFactor`                    | Computes the prime factors of a number.                                    |
| `setsubset`                      | Handles operations related to sets and subsets.                           |
| `solveRecurranceRelation`        | Solves recurrence relations.                                               |
| `validRsa.py`                    | Validates RSA encryption implementations.                                  |

---

## Prerequisites

To run the scripts, ensure you have:
- **Python**: Version 3.8 or higher.
- **Virtual Environment**: Optional but recommended for dependency isolation.

---

## Installation

1. Clone the repository:
   ```bash
   git clone <repository-URL>
   cd Diskret

python -m venv venv
source venv/bin/activate      # Linux/Mac
venv\Scripts\activate         # Windows

Contributing
Contributions are welcome! Follow these steps:

Fork the repository.
Create a new branch for your changes:
bash
Kopier kode
git checkout -b feature-branch-name
Commit your changes:
bash
Kopier kode
git commit -m "Add new feature or fix"
Push the branch and create a pull request.
License
This project is licensed under the MIT License. For details, refer to the LICENSE file. 
👍
