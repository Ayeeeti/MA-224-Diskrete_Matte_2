from collections import defaultdict

class CFG:
    def __init__(self):
        self.rules = defaultdict(list)

    def add_rule(self, non_terminal, rule):
        # Add a rule to the grammar
        self.rules[non_terminal].append(rule.split())

    def check_ambiguity(self, start_symbol, max_depth=5):
        # This function generates strings from the grammar and checks for ambiguity
        generated_strings = set()
        for depth in range(1, max_depth + 1):
            new_strings = self.generate_strings(start_symbol, depth)
            if any(new_string in generated_strings for new_string in new_strings):
                return True  # Ambiguity detected
            generated_strings.update(new_strings)
        return False  # No ambiguity detected

    def generate_strings(self, symbol, depth):
        if depth == 0:
            return {symbol} if symbol.islower() else set()  # Only terminals at depth 0
        if symbol.islower():
            return {symbol}  # Terminal, return itself

        # If non-terminal, expand it
        results = set()
        for rule in self.rules[symbol]:
            subresults = {""}
            for part in rule:
                subpart_results = set()
                for subresult in subresults:
                    for expansion in self.generate_strings(part, depth - 1):
                        subpart_results.add(subresult + expansion)
                subresults = subpart_results
            results.update(subresults)
        return results

def main():
    grammar = CFG()
    
    print("Enter your grammar rules one by one. Type 'done' when finished.")
    while True:
        rule_input = input("Enter a rule (e.g., A -> h | h N) or 'done' to finish: ")
        
        if rule_input.lower() == 'done':
            break
        
        try:
            # Split input into non-terminal and production rule
            non_terminal, productions = rule_input.split('->')
            non_terminal = non_terminal.strip()
            production_list = productions.split('|')
            
            for production in production_list:
                grammar.add_rule(non_terminal, production.strip())
            
            print(f"Rule '{non_terminal} -> {productions}' added.")
        except ValueError:
            print("Invalid input format. Please follow the format: A -> h | h N")
    
    # Ask for the start symbol
    start_symbol = input("Enter the start symbol: ").strip()
    
    # Check for ambiguity
    is_ambiguous = grammar.check_ambiguity(start_symbol)
    print(f"Grammar is {'ambiguous' if is_ambiguous else 'not ambiguous'} with the start symbol {start_symbol}.")

if __name__ == "__main__":
    main()
