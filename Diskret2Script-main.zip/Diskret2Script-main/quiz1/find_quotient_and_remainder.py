def find_quotient_and_remainder(a, b):
    quotient = a // b  # Integer division
    remainder = a % b  # Modulus
    return quotient, remainder

# Example usage
num1 = int(input("Enter the first number (dividend): "))
num2 = int(input("Enter the second number (divisor): "))

quotient, remainder = find_quotient_and_remainder(num1, num2)

print(f"The quotient of {num1} // {num2} is {quotient}")
print(f"The remainder of {num1} % {num2} is {remainder}")
