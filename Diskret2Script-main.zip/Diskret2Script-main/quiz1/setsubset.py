def compute_equivalence_classes(relation, elements):
    equivalence_classes = {}
    
    for element in elements:
        # Compute the key based on the relation
        key = eval(relation.replace("x", str(element)))
        
        # Group elements with the same key
        if key not in equivalence_classes:
            equivalence_classes[key] = set()
        equivalence_classes[key].add(element)
    
    # Convert dictionary values to a set of sets
    result = list(equivalence_classes.values())
    return result

def format_output(equivalence_classes):
    # Format the equivalence classes as a string
    formatted_classes = "{" + ",".join("{" + ",".join(str(e) for e in sorted(eq_class)) + "}" for eq_class in equivalence_classes) + "}"
    return formatted_classes

def main():
    # Input the equivalence relation
    relation = input("Enter the equivalence relation (e.g., x % 12): ").strip()
    
    # Input the set elements as a comma-separated string
    set_input = input("Enter the set elements separated by commas: ").strip()
    
    # Replace any Unicode minus sign (−) with a standard hyphen (-)
    set_input = set_input.replace("−", "-")
    
    # Convert the input into a list of integers
    elements = [int(x) for x in set_input.split(",")]
    
    # Compute the equivalence classes
    equivalence_classes = compute_equivalence_classes(relation, elements)
    
    # Format the output
    formatted_result = format_output(equivalence_classes)
    
    # Output the formatted result
    print("\nEquivalence Classes:")
    print(formatted_result)

if __name__ == "__main__":
    main()
