import json
import sys


def parse_rules(rules_str):
    """Parse the grammar rules into a dictionary, handling both '->' and '→' symbols."""
    rules = {}
    for rule in rules_str.split(','):
        # Handle both '->' and '→' symbols for rule definitions
        if '->' in rule:
            left, right = rule.split('->')
        elif '→' in rule:  # Unicode arrow
            left, right = rule.split('→')
        else:
            raise ValueError("Invalid rule format. Ensure rules use '->' or '→'.")

        right_options = list(right.split('|'))
        rules[left] = right_options
    return rules


def apply_rule(derivation, rules, end_string, steps, memo = {}):
    """Recursive function to find a derivation of the string, avoiding infinite loops."""
    # if we have seen this case before:
    if derivation in memo:
        return memo[derivation]

    # base case for success
    if derivation == end_string:
        steps.append(derivation)
        memo[derivation] = (True, steps)
        return memo[derivation]

    # base casae for total failure (so we don't get infinite recursion)
    if len(derivation) > len(end_string):
        memo[derivation] = (False, steps)
        return memo[derivation]

    # for each character in the derivation
    for i, c in enumerate(derivation):
        # check if that character can be transformed (non terminal)
        if c in rules:
            # for all the rules for that character:
            for r in rules[c]:
                new_der = derivation[:i] + r + derivation[i+1:]
                new_step = steps + [derivation]
                # perform the recurstion
                success, result = apply_rule(new_der, rules, end_string, new_step)
                # check the result of the recursion
                if success:
                    memo[derivation] = (True, result)
                    return True, result

    memo[derivation] = (False, steps)
    return False, steps


def main(rule_str=None, starting_point=None, ending_string=None):
    """Main function obviously runs as the main operation?|"""
    called_by_program = True
    if not (rule_str and starting_point and ending_string):
        called_by_program = False
        if len(sys.argv) != 4:
            print("Usage: python string_derivation.py [rules (separated by ',')] [starting point] [ending string]")
            print("NOTE: this script is case sensitive")
            print("f.eks: python string_derivation.py \"B → Z | B . B, Z → N | N / Z | ε, N → u | f | o | y | g | b | ε\" B \"o / g / g . b\"")
            sys.exit(1)

        rule_str = sys.argv[1]
        starting_point = sys.argv[2]
        ending_string = sys.argv[3]

    rule_str = rule_str.replace(" ", "")
    starting_point = starting_point.replace(" ", "")
    ending_string = ending_string.replace(" ", "")

    rules = parse_rules(rule_str)
    success, steps = apply_rule(starting_point, rules, ending_string, [])
    if success:
        print("Derivation steps:")
        print('[' + ','.join([f'"{step}"' for step in steps]) + ']')
        result = {
            "status": "success",
            "derivation_steps": steps
        }
    else:
        print(f"Could not derive the string '{ending_string}' from the starting symbol '{starting_point}'.")
        result = {
            "status": "failure",
            "error": f"Could not derive the string '{ending_string}' from the starting symbol '{starting_point}'."
        }

    if called_by_program:
        return json.dumps(result)


if __name__ == "__main__":
    main()
