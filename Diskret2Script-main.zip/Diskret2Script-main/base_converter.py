def convert_from_base_to_decimal(number_str, base):
    """
    Converts a number string `number_str` from the specified `base` to base 10.
    """
    try:
        return int(number_str, base)
    except ValueError:
        return f"Invalid number {number_str} for base {base}"

def convert_to_base(n, base):
    """
    Converts a number `n` (in base 10) to the specified `base` and returns the result as a list of digits and intermediate division steps.
    """
    if base < 2:
        return "Base must be 2 or greater."
    
    if n == 0:
        return {'base_representation': '0', 'intermediate_steps': [0]}
    
    result = []
    steps = []
    
    while n > 0:
        quotient, remainder = divmod(n, base)
        result.append(remainder)
        steps.append(n)
        n = quotient
    
    result.reverse()
    
    return {
        'base_representation': ''.join(str(digit) for digit in result),
        'intermediate_steps': steps
    }

def base_conversion():
    """
    Prompts the user for input number, its base, and the target base, then performs the conversion.
    """
    number_str = input("Enter the number to convert: ")
    input_base = int(input("Enter the base of the input number: "))
    target_base = int(input("Enter the base to convert to: "))

    # Step 1: Convert from the original base to base 10
    decimal_value = convert_from_base_to_decimal(number_str, input_base)
    
    if isinstance(decimal_value, str):
        print(decimal_value)
        return

    print(f"\nDecimal (base 10) value of {number_str}_{input_base}: {decimal_value}")

    # Step 2: Convert from base 10 to the target base
    conversion = convert_to_base(decimal_value, target_base)

    # Output results
    print(f"Number {number_str}_{input_base} in base {target_base}: {conversion['base_representation']}")
    print(f"Intermediate steps (division results): {conversion['intermediate_steps']}")

# Run the conversion script
base_conversion()
