def generate_strings(symbol, rules, max_depth=10, current_depth=0):
    """
    Recursively generates strings from a given symbol using the CFG rules.
    Args:
        symbol (str): The current symbol to expand.
        rules (dict): A dictionary of production rules.
        max_depth (int): Maximum recursion depth to avoid infinite loops.
        current_depth (int): Current recursion depth.
    Returns:
        A set of generated strings.
    """
    # If recursion depth is exceeded, stop recursion to avoid infinite loops.
    if current_depth > max_depth:
        return set()

    # If the symbol is a terminal, return it directly as a possible string.
    if symbol.islower():
        return {symbol}

    generated = set()

    # Recursively apply rules
    for production in rules.get(symbol, []):
        # Start with an empty set to combine results
        possibilities = ['']

        # For each symbol in the production rule
        for s in production:
            new_possibilities = []
            generated_symbols = generate_strings(s, rules, max_depth, current_depth + 1)
            for string in possibilities:
                for gen_symbol in generated_symbols:
                    new_possibilities.append(string + gen_symbol)
            possibilities = new_possibilities

        # Add all possible strings generated from this rule
        generated.update(possibilities)

    return generated


def can_generate_string(input_string, rules):
    """
    Check if the input string can be generated using the grammar rules starting from 'S'.
    """
    generated_strings = generate_strings('S', rules)
    return input_string in generated_strings


def input_grammar():
    """
    Takes interactive input from the user to define the grammar.
    """
    print("Enter the terminal symbols (e.g., a, b, c) separated by spaces:")
    terminals = input().split()

    print("Enter the non-terminal symbols (e.g., S, A, B, C) separated by spaces:")
    non_terminals = input().split()

    print("Define production rules. Use the format: Non-terminal -> Production (e.g., S -> AB).")
    print("Type 'done' when you have entered all the rules.")

    rules = {}
    while True:
        rule = input("Enter a production rule: ").strip()
        if rule.lower() == 'done':
            break

        # Validate that the rule contains '->'
        if '->' not in rule:
            print("Error: Production rule must contain '->'. Try again.")
            continue

        lhs, rhs = rule.split("->")

        # Clean up any extra spaces and ensure it's in the right format
        lhs = lhs.strip()
        rhs = [char for char in rhs.strip()]  # Split RHS into individual characters

        if lhs not in rules:
            rules[lhs] = []

        rules[lhs].append(rhs)

    return rules


def input_strings():
    """
    Takes interactive input from the user for strings to check against the grammar.
    """
    print("Enter the strings to check (separated by spaces):")
    strings = input().split()
    return strings


# Main Interactive Process
if __name__ == "__main__":
    # Input the grammar
    print("=== Define the Grammar ===")
    rules = input_grammar()

    # Input the strings to check
    print("\n=== Enter Strings to Check ===")
    strings_to_check = input_strings()

    # Check each string
    for string in strings_to_check:
        result = can_generate_string(string, rules)
        print(f"Can generate '{string}': {result}")
