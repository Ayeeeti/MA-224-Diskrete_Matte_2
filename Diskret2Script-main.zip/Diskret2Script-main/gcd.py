from math import gcd
from functools import reduce

def gcd_multiple(numbers):
    return reduce(gcd, numbers)

def lcm(a, b):
    return abs(a * b) // gcd(a, b)

def lcm_multiple(numbers):
    return reduce(lcm, numbers)

# Example usage
nums = list(map(int, input("Enter the numbers separated by spaces: ").split()))

gcd_result = gcd_multiple(nums)
lcm_result = lcm_multiple(nums)

print(f"The GCD of {nums} is {gcd_result}")
print(f"The LCM of {nums} is {lcm_result}")
