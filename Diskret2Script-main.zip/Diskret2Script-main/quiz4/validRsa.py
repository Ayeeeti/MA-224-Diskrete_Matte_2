from sympy import isprime

def is_valid_rsa_key(x, y, p, q, n):
    """
    Function to validate if the provided x, y, p, q, and n form a valid RSA key pair.
    """
    # Check if p and q are primes
    if not (isprime(p) and isprime(q)):
        return False, "p and/or q are not prime numbers."
    
    # Check if n equals p * q
    if n != p * q:
        return False, "n does not equal p * q."
    
    # Calculate phi(n)
    phi_n = (p - 1) * (q - 1)
    
    # Check if x * y mod phi(n) = 1
    if (x * y) % phi_n != 1:
        return False, "x * y mod phi(n) does not equal 1."
    
    # All checks passed
    return True, "Valid RSA key pair."

def main():
    print("Enter the values for RSA validation:")
    x = int(input("x (public exponent): "))
    y = int(input("y (private exponent): "))
    p = int(input("p (prime number): "))
    q = int(input("q (prime number): "))
    n = int(input("n (modulus): "))

    # Validate the RSA key pair
    is_valid, message = is_valid_rsa_key(x, y, p, q, n)
    
    # Print the result
    if is_valid:
        print("The given values form a VALID RSA key pair.")
    else:
        print(f"The given values are INVALID: {message}")

if __name__ == "__main__":
    main()
