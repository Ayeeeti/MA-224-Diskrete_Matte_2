from sympy import primefactors, mod_inverse

def rsa_solver():
    print("RSA Solver for Task (a) and (b)")

    # Task (a): Input n and x, and compute private key y
    n = int(input("Enter n (modulus): "))
    x = int(input("Enter x (public exponent): "))

    # Factorize n to find p and q
    factors = primefactors(n)
    if len(factors) != 2:
        print("Error: n must be the product of two prime numbers.")
        return

    p, q = factors

    # Compute φ(n)
    phi_n = (p - 1) * (q - 1)

    # Compute the private key y
    try:
        y = mod_inverse(x, phi_n)
        print(f"\nTask (a): The private key y = {y}")
    except ValueError:
        print("Error: x has no modular inverse modulo φ(n).")
        return

    print(f"Factors of n: p = {p}, q = {q}")
    print(f"φ(n) = {phi_n}")

    # Task (b): Input encrypted message M and decrypt it
    M = int(input("\nEnter M (encrypted message): "))

    # Decrypt the message
    m = pow(M, y, n)  # Decrypt using m = M^y mod n
    print(f"\nTask (b): The decrypted (plain text) message is: m = {m}")

# Run the script
if __name__ == "__main__":
    rsa_solver()
