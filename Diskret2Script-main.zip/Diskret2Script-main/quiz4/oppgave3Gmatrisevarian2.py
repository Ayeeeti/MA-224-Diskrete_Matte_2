import numpy as np

def hamming_decoder():
    print("Hamming Code Decoder")

    # Step 1: Input generator matrix dimensions and values
    rows = int(input("Enter the number of rows in the generator matrix (G): "))
    cols = int(input("Enter the number of columns in the generator matrix (G): "))
    print("Enter the generator matrix (row by row, space-separated):")
    G = []
    for _ in range(rows):
        row = list(map(int, input().strip().split()))
        G.append(row)
    G = np.array(G)
    print(f"\nGenerator Matrix G:\n{G}")

    # Step 2: Input the received bitstring (r)
    r = np.array([int(b) for b in input("\nEnter the received bitstring r: ").strip()])
    print(f"Received bitstring r: {r}")

    # Step 3: Compute the syndrome (S = r * H^T mod 2)
    H = np.concatenate((G[:, rows:].T, np.eye(cols - rows, dtype=int)), axis=1)  # Compute H from G
    S = np.dot(r, H.T) % 2
    print(f"\n(a) Syndrome S: {''.join(map(str, S))}")

    # Step 4: Compute the error pattern (e) based on S
    error_index = int(''.join(map(str, S)), 2)  # Convert syndrome to decimal index
    e = np.zeros(cols, dtype=int)
    if error_index != 0:
        e[error_index - 1] = 1  # Error at position error_index
    print(f"(b) Error pattern e: {''.join(map(str, e))}")

    # Step 5: Compute the corrected codeword (c = r + e mod 2)
    c = (r + e) % 2
    print(f"(c) Corrected codeword c: {''.join(map(str, c))}")

if __name__ == "__main__":
    hamming_decoder()
