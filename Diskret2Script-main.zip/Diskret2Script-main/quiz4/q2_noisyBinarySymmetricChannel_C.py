from math import comb

def binary_symmetric_channel():
    print("Binary Symmetric Channel Calculator")

    # Input all necessary information at the start
    p = float(input("Enter the error probability p (e.g., 0.051): "))
    n = int(input("Enter the length of the bitstring w: "))
    k = int(input("Enter the maximum number of bit errors for task b (e.g., 2): "))
    w = input("Enter the transmitted bitstring w (e.g., 1011010): ")
    r = input("Enter the received bitstring r (e.g., 1000010): ")

    # Task (a): Probability of no errors
    prob_no_errors = (1 - p) ** n  # No errors means all bits transmitted correctly

    # Task (b): Probability of at most k errors
    prob_at_most_k_errors = 0
    for i in range(k + 1):  # Sum probabilities for 0 to k errors
        prob_at_most_k_errors += comb(n, i) * (p ** i) * ((1 - p) ** (n - i))

    # Task (c): Probability of transmitting w and receiving r
    # Calculate the number of differing bits (Hamming distance)
    errors = sum(1 for bit_w, bit_r in zip(w, r) if bit_w != bit_r)
    prob_transmitting_w_receiving_r = (p ** errors) * ((1 - p) ** (n - errors))

    # Output results
    print("\nResults:")
    print(f"(a) Probability of no errors: {prob_no_errors:.3f}")
    print(f"(b) Probability of at most {k} errors: {prob_at_most_k_errors:.3f}")
    print(f"(c) Probability of transmitting w and receiving r: {prob_transmitting_w_receiving_r:.3f}")

if __name__ == "__main__":
    binary_symmetric_channel()
