def hamming_distance(bitstring1, bitstring2):
    """
    Calculate the Hamming distance between two bitstrings of equal length.
    """
    return sum(b1 != b2 for b1, b2 in zip(bitstring1, bitstring2))

def find_min_max_hamming_distance(bitstrings):
    """
    Find the minimum and maximum Hamming distance between any two bitstrings in a set.
    """
    n = len(bitstrings)
    min_distance = float('inf')
    max_distance = float('-inf')
    
    # Compare all pairs of bitstrings
    for i in range(n):
        for j in range(i + 1, n):
            distance = hamming_distance(bitstrings[i], bitstrings[j])
            min_distance = min(min_distance, distance)
            max_distance = max(max_distance, distance)
    
    return min_distance, max_distance

def main():
    print("Enter the bitstrings separated by spaces (e.g., '000010 010000 001001 000100'):")
    user_input = input().strip()
    bitstrings = user_input.split()
    
    # Validate input lengths
    if not all(len(bitstrings[0]) == len(b) for b in bitstrings):
        print("Error: All bitstrings must have the same length.")
        return
    
    l_min, l_max = find_min_max_hamming_distance(bitstrings)
    print(f"Minimum Hamming distance (l_min): {l_min}")
    print(f"Maximum Hamming distance (l_max): {l_max}")

if __name__ == "__main__":
    main()
