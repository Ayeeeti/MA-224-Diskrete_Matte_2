import numpy as np
from itertools import combinations

def solve_encoding_problem():
    # Ask for the number of rows and columns in the generator matrix G
    rows = int(input("Enter the number of rows in the generator matrix G: "))
    cols = int(input("Enter the number of columns in the generator matrix G: "))
    
    # User input for the generator matrix G
    print(f"Enter the {rows} x {cols} generator matrix G row by row (space-separated values).")
    G = []
    for i in range(rows):
        row = list(map(int, input(f"Enter row {i+1}: ").strip().split()))
        if len(row) != cols:
            print(f"Error: Row {i+1} must have {cols} values.")
            return
        G.append(row)
    G = np.array(G)

    # Generate all possible input vectors of length `rows`
    num_vectors = 2**rows
    w_vectors = [np.array([int(b) for b in f"{i:0{rows}b}"]) for i in range(num_vectors)]

    # Compute codewords E(w) = w * G mod 2
    codewords = [np.dot(w, G) % 2 for w in w_vectors]

    # Part (a): Compute the minimum distance between any two codewords
    hamming_distances = []
    for c1, c2 in combinations(codewords, 2):
        hamming_distances.append(np.sum(c1 != c2))  # Count differing positions
    l_min = min(hamming_distances)

    # Part (b): Find a non-zero codeword
    c_non_zero = codewords[1]  # Use the second codeword, since the first is always zero

    # Part (c): Find a bitstring that is not a codeword
    all_bitstrings = [np.array([int(b) for b in f"{i:0{cols}b}"]) for i in range(2**cols)]  # All possible bitstrings
    non_codeword = None
    for b in all_bitstrings:
        if not any(np.array_equal(b, c) for c in codewords):
            non_codeword = b
            break

    # Output results
    print("\nResults:")
    print(f"(a) Minimum Hamming distance (l_min): {l_min}")
    print(f"(b) Non-zero codeword: {''.join(map(str, c_non_zero))}")
    print(f"(c) A bitstring not in the codewords: {''.join(map(str, non_codeword))}")

if __name__ == "__main__":
    solve_encoding_problem()
