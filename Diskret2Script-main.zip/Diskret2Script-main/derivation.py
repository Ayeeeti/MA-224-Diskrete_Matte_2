import sys


def parse_rules(rules_str):
    """Parse the grammar rules into a dictionary, handling both '->' and '→' symbols."""
    rules = {}
    for rule in rules_str.split(','):
        # Handle both '->' and '→' symbols for rule definitions
        if '->' in rule:
            left, right = rule.split('->')
        elif '→' in rule:  # Unicode arrow
            left, right = rule.split('→')
        else:
            raise ValueError("Invalid rule format. Ensure rules use '->' or '→'.")

        right_options = list(right.split('|'))
        rules[left] = right_options
    return rules


def apply_rule(derivation, rules, end_string, steps, memo = {}):
    """Recursive function to find a derivation of the string, avoiding infinite loops."""
    # if we have seen this case before:
    if derivation in memo:
        return memo[derivation]

    # base case for success
    if derivation == end_string:
        steps.append(derivation)
        memo[derivation] = (True, steps)
        return memo[derivation]

    # base casae for total failure (so we don't get infinite recursion)
    if len(derivation) > len(end_string):
        memo[derivation] = (False, steps)
        return memo[derivation]

    # for each character in the derivation
    for i, c in enumerate(derivation):
        # check if that character can be transformed (non terminal)
        if c in rules:
            # for all the rules for that character:
            for r in rules[c]:
                new_der = derivation[:i] + r + derivation[i+1:]
                new_step = steps + [derivation]
                # perform the recurstion
                success, result = apply_rule(new_der, rules, end_string, new_step)
                # check the result of the recursion
                if success:
                    memo[derivation] = (True, result)
                    return True, result

    memo[derivation] = (False, steps)
    return False, steps


def main():
    """Main function obviously runs as the main operation?|"""
    if len(sys.argv) != 4:
        print("Usage: python string_derivation.py [rules (separated by ',')] [starting point] [ending string]")
        print("NOTE: this script is case sensitive")
        sys.exit(1)

    rule_str = sys.argv[1].replace(" ", "")
    starting_point = sys.argv[2]
    ending_string = sys.argv[3].replace(" ", "")

    rules = parse_rules(rule_str)
    success, steps = apply_rule(starting_point, rules, ending_string, [])
    if success:
        print("Derivation steps:")
        print('[' + ','.join([f'"{step}"' for step in steps]) + ']')
    else:
        print(f"Could not derive the string '{ending_string}' from the starting symbol '{starting_point}'.")


if __name__ == "__main__":
    main()
