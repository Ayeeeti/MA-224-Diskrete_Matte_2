import sympy as sp
import re

def parse_recurrence_relation(recurrence_str):
    """
    Parses the recurrence relation string and extracts coefficients of a_(n-1) and a_(n-2).
    Expected format: "a_n - c1 * a_(n-1) + c2 * a_(n-2) = 0" or "a_n = c1 * a_(n-1) + c2 * a_(n-2)"
    """
    # Remove spaces for easier parsing
    recurrence_str = recurrence_str.replace(" ", "")
    # Remove 'a_n' and '=0' or '='
    recurrence_str = recurrence_str.replace("a_n", "").replace("=0", "").replace("=", "").strip()
    # Replace a_(n-1) and a_(n-2) with single characters for simplicity
    recurrence_str = recurrence_str.replace("a_(n-1)", "x").replace("a_(n-2)", "y")
    
    # Use regex to match terms
    terms = re.findall(r'[\+\-]?[^+\-]+', recurrence_str)

    c1, c2 = 0, 0
    for term in terms:
        term = term.strip()
        if "x" in term:  # term with a_(n-1)
            coeff = term.replace("x", "")
            if coeff in ("", "+"):
                coeff = "1"
            elif coeff == "-":
                coeff = "-1"
            c1 = int(coeff)
        elif "y" in term:  # term with a_(n-2)
            coeff = term.replace("y", "")
            if coeff in ("", "+"):
                coeff = "1"
            elif coeff == "-":
                coeff = "-1"
            c2 = int(coeff)
    
    return c1, c2

def solve_recurrence_relation(recurrence_str, a_0, a_1):
    """
    Solves a second-order linear homogeneous recurrence relation with constant coefficients.
    
    Parameters:
    - recurrence_str: String representing the recurrence relation in terms of a_n, a_(n-1), a_(n-2).
    - a_0: Initial condition a_0.
    - a_1: Initial condition a_1.
    
    Returns:
    - A simplified expression representing a_n in terms of n.
    """
    # Parse the recurrence relation to get coefficients
    c1, c2 = parse_recurrence_relation(recurrence_str)
    
    # Define symbols
    n = sp.symbols('n')
    C1, C2 = sp.symbols('C1 C2')  # Constants to solve for
    
    # Characteristic equation: r^2 - c1 * r - c2 = 0
    r = sp.symbols('r')
    characteristic_eq = sp.Eq(r**2 - c1 * r - c2, 0)
    roots = sp.solve(characteristic_eq, r)
    
    # Determine the general solution based on the roots
    if len(roots) == 2 and roots[0] != roots[1]:  # Distinct roots
        r1, r2 = roots
        general_solution = C1 * r1**n + C2 * r2**n
    else:  # Repeated root
        r1 = roots[0]
        general_solution = (C1 + C2 * n) * r1**n
    
    # Apply initial conditions to solve for C1 and C2
    equations = [
        sp.Eq(general_solution.subs(n, 0), a_0),
        sp.Eq(general_solution.subs(n, 1), a_1)
    ]
    constants = sp.solve(equations, (C1, C2))
    
    # Substitute the constants back into the general solution
    particular_solution = general_solution.subs(constants)
    
    # Return the particular solution as a simplified expression
    return sp.simplify(particular_solution)

# Interactive input
if __name__ == "__main__":
    # Prompt user for input
    recurrence_str = input("Enter the recurrence relation (e.g., 'a_n - 2*a_(n-1) + 1*a_(n-2) = 0'): ")
    a_0 = int(input("Enter the initial condition a_0: "))
    a_1 = int(input("Enter the initial condition a_1: "))
    
    # Solve the recurrence relation
    solution = solve_recurrence_relation(recurrence_str, a_0, a_1)
    
    # Display the solution
    print("\nSolution a_n as a function of n:")
    print(solution)
