def prime_factors(n):
    factors = []
    
    # Divide n by 2 until it's odd
    while n % 2 == 0:
        factors.append(2)
        n = n // 2

    # Check for odd factors from 3 upwards
    for i in range(3, int(n**0.5) + 1, 2):
        while n % i == 0:
            factors.append(i)
            n = n // i

    # If n is still greater than 2, it must be prime
    if n > 2:
        factors.append(n)

    return factors

# Input from the user
number = int(input("Enter a number to find its prime factors: "))
print("Prime factors of", number, "are:", prime_factors(number))
