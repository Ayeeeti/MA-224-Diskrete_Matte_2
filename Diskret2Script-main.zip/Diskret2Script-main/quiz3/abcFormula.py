import cmath
import re

def parse_equation(equation):
    # Remove whitespaces and lowercase the equation
    equation = equation.replace(" ", "").lower()
    
    # Extract coefficients using regex
    match = re.match(r'([+-]?\d*)r\^2([+-]?\d*)r([+-]?\d+)=0', equation)
    
    if not match:
        raise ValueError("Equation format should be like 'ar^2 + br + c = 0'")
    
    # Convert matches to integers, handling signs and missing coefficients
    a = int(match.group(1) or "1")
    b = int(match.group(2) or "1")
    c = int(match.group(3) or "0")
    
    return a, b, c

def solve_quadratic(a, b, c):
    # Calculate the discriminant
    discriminant = b**2 - 4 * a * c

    # Calculate the two solutions using the quadratic formula
    root1 = (-b + cmath.sqrt(discriminant)) / (2 * a)
    root2 = (-b - cmath.sqrt(discriminant)) / (2 * a)

    return root1, root2

# User input for the equation
equation = input("Enter a quadratic equation in the form 'ar^2 + br + c = 0': ")
a, b, c = parse_equation(equation)

# Solve and display the roots
roots = solve_quadratic(a, b, c)
print(f"The roots of the equation are: {roots[0]} and {roots[1]}")

