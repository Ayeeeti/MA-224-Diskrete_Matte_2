def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def lcd(a, b):
    return abs(a * b) // gcd(a, b)

# Example usage
num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))

result = lcd(num1, num2)
print(f"The LCD of {num1} and {num2} is {result}")
