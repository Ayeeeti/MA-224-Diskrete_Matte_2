def find_mod(a, b):
    return a % b

# Example usage
num1 = int(input("Enter the first number (dividend): "))
num2 = int(input("Enter the second number (divisor): "))

result = find_mod(num1, num2)
print(f"The modulus of {num1} % {num2} is {result}")
